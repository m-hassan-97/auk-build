module.exports = {
    images: {
      domains: ['ahsan-ul-kalam.s3.amazonaws.com'],
    },
  }