<!-- # flexy-bootstrap-lite-- >
<!-- Heading of Template -->
<h3><a href="https://flexy-mui-nextjs-free.netlify.app/">Live Demo</a></h3>
<h1>
  Flexy Next Js Free Admin
</h1>

<!-- Main image of Template -->
<a target="_blank" href="https://www.wrappixel.com/templates/flexy-next-js-free-admin-template/">
  <img src="https://www.wrappixel.com/wp-content/uploads/edd/2022/01/flexy-nextjs-free.jpg" />
</a>

<!-- Description of Template -->
<p>
 Flexy Free Nextjs version is built with Most Popular Framework React Material-UI.

The free version comes with elegant grid design that helps you play around with the look and feel of the web app the way you want. it's carefully hand crafted minimal admin template, Its build with modular and modern design.

People love this react dashboard as it is well-known for creating a seamless experience for users with modern design helping to execute complex requirements. It readily offers UI elements, creative pages, and user-friendliness environment.
</p>

<!-- <h4><a href="https://wrappixel.com/demos/free-admin-templates/xtreme-admin-lite/xtreme-html/ltr/index.html">Free Version Demo Link</a></h4> -->

<!-- ## Pro Version -->

<!-- <a href="https://www.wrappixel.com/templates/xtremeadmin/"><img src="https://www.wrappixel.com/wp-content/uploads/2019/01/xtreme-admin-bootstrap-nw-1.jpg"/></a><br/>
<h4><a href="https://www.wrappixel.com/demos/admin-templates/xtreme-admin/html/ltr/index.html">Demo</a></h4> -->

<!-- Versions of Template -->
<h2><a id="user-content-versions" class="anchor" aria-hidden="true" href="#versions"></a>Versions</h2>
<table>
<thead>
<tr>
<th>Bootstrap</th>
<th>React</th>
<th>Angular</th>
<th>NextJs</th>
</tr>
</thead>
<tbody>
<tr>
<td>
  <a href="https://www.wrappixel.com/templates/flexy-bootstrap-admin-template/" rel="nofollow" width="150px">
    <img src="https://www.wrappixel.com/wp-content/uploads/edd/2021/05/flexy.jpg" alt="Flexy Template  Bootstrap" style="max-width:150px;">
  </a>
</td>
<td>
  <a href="https://www.wrappixel.com/templates/flexy-react-material-dashboard-admin/" rel="nofollow" width="150px">
    <img src="https://www.wrappixel.com/wp-content/uploads/edd/2021/07/flexy-react-admin.jpg" alt="Flexy Template  React" style="max-width:150px;">
  </a>
</td>
      <td>
  <a href="https://www.wrappixel.com/templates/flexy-material-angular-admin/" rel="nofollow" width="150px">
    <img src="https://www.wrappixel.com/wp-content/uploads/2022/03/flexy-angular-pro.jpg" alt="Flexy Template  Angular" style="max-width:150px;">
  </a>
</td>
  <td>
  <a href="https://www.wrappixel.com/templates/flexy-nextjs-dashboard-material-ui/" rel="nofollow" width="150px">
    <img src="https://www.wrappixel.com/wp-content/uploads/edd/2022/04/nextjs-flexy.jpg" alt="Flexy Template  NextJs" style="max-width:150px;">
  </a>
</td>
</tr>
</tbody>
</table>

<!-- Resources of Template -->
<h2>Resources</h2>
<ul>
<li>  
  Live Demo: <a href="https://demos.wrappixel.com/free-admin-templates/nextjs/flexy-nextjs-admin-free-dist/landingpage/" rel="nofollow">https://demos.wrappixel.com/free-admin-templates/nextjs/flexy-nextjs-admin-free-dist/landingpage/</a>
</li>
<li>
    Download Page: <a href="https://www.wrappixel.com/templates/flexy-next-js-free-admin-template/" rel="nofollow">
  https://www.wrappixel.com/templates/flexy-next-js-free-admin-template/</a>
</li>
<li>
    <a href="https://www.wrappixel.com/templates/wrapkit/#demos" rel="nofollow">WrapKit </a>Complete UI Kit - For Website Projects
</li>
</ul>

<!-- Licensing of Template -->
<h2>Licensing</h2>
<ul>
  <li>
    <p>Copyright 2022 Wrappixel (<a href="https://www.wrappixel.com/" rel="nofollow">https://www.wrappixel.com/</a>)</p>
  </li>
  <li>
    <p>Licensed under MIT (<a href="https://www.wrappixel.com/license/">https://www.wrappixel.com/license/</a>)</p>
  </li>
</ul>


<!-- Upgrade to Premium version of Template -->
<h2>Upgrade to Premium version</h2>
<a target="_blank" href="https://www.wrappixel.com/templates/flexy-nextjs-dashboard-material-ui/">
  <img src="https://www.wrappixel.com/wp-content/uploads/edd/2022/04/nextjs-flexy.jpg" />
</a>
<p>
   Checkout our premium version of Flexy NextJs Admin for lots more features and ready to use page templates.<br>
   <a href="https://flexy-next-js-dashboard.vercel.app/dashboards/dashboard1">Check Live Preview</a> | <a href="https://www.wrappixel.com/templates/flexy-nextjs-dashboard-material-ui/">Download</a>
</p>

<!-- Useful Links of Template -->
<h2>Useful Links</h2>
<ul>
<li><a href="https://www.wrappixel.com/templates/category/admin-template/">Admin Panel Template</a> from WrapPixel</li>
<li><a href="https://www.wrappixel.com/">Free Bootstrap 5 Themes</a> from WrapPixel</li>
<li><a href="https://www.wrappixel.com/templates/category/bootstrap-admin-templates/">Bootstrap 5 Admin Template</a> from WrapPixel</li>
<li><a href="https://www.wrappixel.com/templates/category/angular-templates/">Angular JS Dashboard</a> from WrapPixel</li>
<li><a href="https://www.wrappixel.com/templates/category/react-templates/">React Website Templates</a> from WrapPixel</li>
<li><a href="https://www.wrappixel.com/templates/category/vuejs-templates/">Vue JS Templates</a> from WrapPixel</li>
<li><a href="https://www.wrappixel.com/templates/category/free-templates/">Free Themes</a> from WrapPixel</li>
</ul>

<!-- Social Media of Wrappixel -->
<h2>Social Media</h2>
<p>Facebook: <a href="https://www.facebook.com/wrappixel">https://www.facebook.com/wrappixel</a></p>
<p>Twitter: <a href="https://twitter.com/wrappixel">https://twitter.com/wrappixel</a></p>
<p>Medium: <a href="https://medium.com/wrappixel">https://medium.com/wrappixel</a></p>
# auk-build
