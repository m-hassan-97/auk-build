"use client";
import Link from "next/link";
import Swal from "sweetalert2";
import {
  Card,
  CardContent,
  Grid,
  Typography,
  Box,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Chip,
  TableContainer,
  Stack,
  Pagination,
  Button,
} from "@mui/material";
import { useEffect, useState } from "react";
import config from "@/utils/config";
import axios from "axios";
import Image from "next/image";
import aukLogo from "public/images/AuK_logo.webp";

const Page = () => {
  const [data, setData] = useState<any>([]); // Initialize data as null

  const [pagination, setPagination] = useState({ total: 0, currentPage: 1, totalPages: 1, limit: 3 }); // Initialize with default limit
  const { limit, currentPage } = pagination;


  var i = 1;

  useEffect(() => {
    fetchData();
  }, [currentPage, limit]);


  const fetchData = async () => {
    try {
      const response = await axios.request({
        method: "get",
        url: `${config.apiUrl}reciter/all`,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.bearerToken}`,
        },
        params: {
          page: currentPage, // Pass the current page
          limit, // Pass the limit
          offset: (currentPage - 1) * limit, // Calculate offset
        },
      });
      setData(response.data.data.data);
      setPagination({
        total: response.data.data.total,
        currentPage,
        totalPages: Math.ceil(response.data.data.total / limit),
        limit,
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleDelete = async (id: string) => {
    // Prompt user for confirmation using SweetAlert
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "You will not be able to recover this record!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    });

    if (result.isConfirmed) {
      // User confirmed, send DELETE request to API
      axios
        .request({
          method: "delete",
          maxBodyLength: Infinity,
          url: `${config.apiUrl}reciter/${id}`,
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${config.bearerToken}`,
          },
        })
        .then((response) => {
          Swal.fire("Deleted!", "The record has been deleted.", "success");
          setData(data.filter((record: any) => record.id !== id));
        })
        .catch((error) => {
          Swal.fire("Error!", "Failed to delete the record.", "error");
        });
    }
  };

  const handlePageChange = (event:any, page:any) => {

    console.log("pagination.total",pagination);
    

    setPagination((prevPagination) => ({
      ...prevPagination,
      currentPage: page,
    }));
  };

  return (
    <Grid container spacing={0}>
      <Grid item xs={12} lg={12}>
        <Card sx={{ padding: 0 }} elevation={9} variant={undefined}>
          <CardContent sx={{ p: "30px" }}>
            <Stack
              direction="row"
              spacing={2}
              justifyContent="space-between"
              alignItems={"center"}
              mb={3}
            >
              <Box>
                <Typography variant="h3">Manage Reciters</Typography>
              </Box>

              <Link href="reciters/add">
                <Button variant="contained" color="success">
                  Add New
                </Button>
              </Link>
            </Stack>

            <TableContainer
              sx={{
                width: {
                  xs: "274px",
                  sm: "100%",
                },
              }}
            >
              <Table
                aria-label="simple table"
                sx={{
                  whiteSpace: "nowrap",
                  mt: 2,
                }}
              >
                <TableHead>
                  <TableRow>
                    <TableCell>
                      <Typography color="textSecondary" variant="h6">
                        Id
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography color="textSecondary" variant="h6">
                        Name
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography color="textSecondary" variant="h6">
                        Country
                      </Typography>
                    </TableCell>

                    <TableCell>
                      <Typography color="textSecondary" variant="h6">
                        Image
                      </Typography>
                    </TableCell>

                    <TableCell align="right">
                      <Typography color="textSecondary" variant="h6">
                        Action
                      </Typography>
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {data?.map((record: any) => (
                    <TableRow  key={record.id}>
                      <TableCell>
                        <Typography fontSize="15px" fontWeight={500}>
                          {i++}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Box display="flex" alignItems="center">
                          <Box>
                            <Typography variant="h6" fontWeight={600}>
                              {record.name}
                            </Typography>
                          </Box>
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Typography color="textSecondary" variant="h6">
                          {record.country}
                        </Typography>
                      </TableCell>

                      <TableCell>
                        <Image
                          src={record?.image? record.image: aukLogo}
                          alt="img"
                          width={50}
                          height={50}
                          style={{ borderRadius: 25 }}
                        />
                      </TableCell>

                      <TableCell align="right">



                      <Link
                          href={{
                            pathname: `/manage/reciters/${record.id}`,
                          }}
                        >
                          <Chip
                            sx={{
                              pl: "4px",
                              pr: "4px",
                              backgroundColor: "success.main",
                              color: "#fff",
                            }}
                            size="small"
                            label="Update in Quran"
                          ></Chip>
                        </Link>



                        <Chip
                          sx={{
                            pl: "4px",
                            pr: "4px",
                            backgroundColor: "error.main",
                            color: "#fff",
                          }}
                          size="small"
                          label="Delete"
                          onClick={() => handleDelete(record.id)}
                        ></Chip>

                        <Link
                          href={{
                            pathname: `/manage/reciters/edit/${record.id}`,
                          }}
                        >
                          <Chip
                            sx={{
                              pl: "4px",
                              pr: "4px",
                              backgroundColor: "secondary.main",
                              color: "#fff",
                            }}
                            size="small"
                            label="Edit"
                          ></Chip>
                        </Link>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>


              <Pagination
              
                count={pagination.totalPages}
                page={pagination.currentPage}
                color="primary"
                onChange={handlePageChange}
              />
            </TableContainer>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );
};

export default Page;
