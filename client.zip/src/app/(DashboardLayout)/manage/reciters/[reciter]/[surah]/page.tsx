"use client";

import AWS from "aws-sdk";
import Link from "next/link";
import Swal from "sweetalert2";
import {
  Card,
  CardContent,
  Grid,
  Typography,
  Box,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Chip,
  TableContainer,
  Stack,
  Pagination,
  Button,
  TextField,
  FormLabel,
} from "@mui/material";
import { useEffect, useState } from "react";
import config from "@/utils/config";
import axios from "axios";
import Image from "next/image";
import aukLogo from "public/images/AuK_logo.webp";

import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import styled from "@emotion/styled";

const VisuallyHiddenInput = styled("input")({
  clip: "rect(0 0 0 0)",
  clipPath: "inset(50%)",
  height: 1,
  overflow: "hidden",
  position: "absolute",
  bottom: 0,
  left: 0,
  whiteSpace: "nowrap",
  width: 1,
});

const Page = ({ params }: any) => {
  console.log("params", params);

  const surahId = params.surah;

  const reciterId = params.reciter;

  const [data, setData] = useState<any>([]); // Initialize data as null

  const [pagination, setPagination] = useState({
    total: 0,
    currentPage: 1,
    totalPages: 1,
    limit: 10,
  }); // Initialize with default limit
  const { limit, currentPage } = pagination;

  const [recordData, setrecordData] = useState<any>([]); // Initialize data as null

  var i = 1;

  useEffect(() => {
    fetchRecordData();
    fetchData();
  }, [currentPage, limit]);

  const fetchRecordData = async () => {
    try {
      const response = await axios.request({
        method: "get",
        url: `${config.apiUrl}reciter/${reciterId}`,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.bearerToken}`,
        },
      });

      console.log("response.data", response.data.data[0].name);

      setrecordData(response.data?.data[0]?.name);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const fetchData = async () => {
    try {
      const response = await axios.request({
        method: "get",
        url: `${config.apiUrl}surah/${surahId}`,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.bearerToken}`,
        },
        params: {
          page: currentPage, // Pass the current page
          limit, // Pass the limit
          offset: (currentPage - 1) * limit, // Calculate offset
        },
      });

      console.log("response.data.data.total", response.data.data.total);

      setPagination({
        total: response.data.data.total,
        currentPage,
        totalPages: Math.ceil(response.data.data.total / limit),
        limit,
      });

      setData(response.data.data.data[0].ayahs);

      console.log("pagination", pagination);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleDelete = async (id: string) => {
    // Prompt user for confirmation using SweetAlert
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "You will not be able to recover this record!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    });

    if (result.isConfirmed) {
      // User confirmed, send DELETE request to API
      axios
        .request({
          method: "delete",
          maxBodyLength: Infinity,
          url: `${config.apiUrl}reciter/${id}`,
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${config.bearerToken}`,
          },
        })
        .then((response) => {
          Swal.fire("Deleted!", "The record has been deleted.", "success");
          setData(data.filter((record: any) => record.id !== id));
        })
        .catch((error) => {
          Swal.fire("Error!", "Failed to delete the record.", "error");
        });
    }
  };

  const handlePageChange = (event: any, page: any) => {
    console.log("pagination.total", pagination);

    setPagination((prevPagination) => ({
      ...prevPagination,
      currentPage: page,
    }));
  };

  const [image, setImage] = useState<any>("");

  const [selectedFile, setSelectedFile] = useState<any>(null);

  const [fileName, setFileName] = useState<any>("");

  const [uploadingStatus, setUploadingStatus] = useState<boolean>(false);

  async function handleFileChange(event: any, record: any) {
    console.log("event.target.files", event.target.files);

    if (event.target.files[0]) {
      console.log("event.target.files[0]", event.target.files[0]);
      const selectedFileTemp = event.target.files[0];
      await setSelectedFile(event.target.files[0]);

      console.log("selectedFile", selectedFile);
      console.log("selectedFileTemp", selectedFileTemp);

      if (selectedFileTemp) {
        setFileName(selectedFileTemp.name);
      }

      const s3 = new AWS.S3({
        accessKeyId: "AKIAU6GDVB4AKL2MFI5J",
        secretAccessKey: "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",
        region: "us-east-1",
      });
      const params = {
        Bucket: "ahsan-ul-kalam",
        Key: `images/reciter/${selectedFileTemp.name}`,
        Body: selectedFileTemp,
      };
      setUploadingStatus(true);
      console.log("uploadingStatus", uploadingStatus);
      await s3.upload(params, (err: any, data: any) => {
        setUploadingStatus(false);
        console.log("uploadingStatus", uploadingStatus);

        if (err) {
          console.error("Error uploading file:", err);
          return;
        }
        console.log("File uploaded successfully:", data);
        setImage(data.Location);

        updateRecord(data.Location, record.number, reciterId);
      });
    }
  }

  function updateRecord(value: any, ayahNumber: any, reciterId: any) {
    console.log({
      ayahNumber: ayahNumber,
      reciterId: reciterId,
      attachment: value,
    });

    axios
      .request({
        method: "put",
        maxBodyLength: Infinity,
        url: `${config.apiUrl}ayah/recitation`,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.bearerToken}`,
        },
        data: JSON.stringify({
          ayahNumber: ayahNumber,
          reciterId: reciterId,
          attachment: value,
        }),
      })
      .then((response) => {
        console.log("response");
        console.log(response.data);

        window.location.reload();
      });
  }

  return (
    <Grid container spacing={0}>
      <Grid item xs={12} lg={12}>
        <Card sx={{ padding: 0 }} elevation={9} variant={undefined}>
          <CardContent sx={{ p: "30px" }}>
            <Stack
              direction="row"
              spacing={2}
              justifyContent="space-between"
              alignItems={"center"}
              mb={3}
            >
              <Box>
                <Typography variant="h3">Quran</Typography>

                <Typography variant="h4">reciter : {recordData}</Typography>
                <Typography variant="h4">Surah Number : {surahId}</Typography>
              </Box>

              {/* <Link href="reciters/add">
                <Button variant="contained" color="success">
                  Add New
                </Button>
              </Link> */}
            </Stack>

            <TableContainer
              sx={{
                width: {
                  xs: "274px",
                  sm: "100%",
                },
              }}
            >
              <Table
                aria-label="simple table"
                sx={{
                  whiteSpace: "nowrap",
                  mt: 2,
                }}
              >
                <TableHead>
                  <TableRow>
                    <TableCell>
                      <Typography color="textSecondary" variant="h6">
                        Juz
                      </Typography>
                    </TableCell>

                    <TableCell>
                      <Typography color="textSecondary" variant="h6">
                        Ayah
                      </Typography>
                    </TableCell>

                    <TableCell>
                      <Typography color="textSecondary" variant="h6">
                        Juz
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography color="textSecondary" variant="h6">
                        reciter
                      </Typography>
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {data?.map((record: any) => (
                    <TableRow key={record.number}>
                      <TableCell sx={{ width: "5%" }}>
                        <Typography fontSize="15px" fontWeight={500}>
                          {i++}
                        </Typography>
                      </TableCell>

                      <TableCell sx={{ width: "30%" }}>
                        <Typography
                          style={{ textWrap: "wrap" }}
                          color="textSecondary"
                          variant="h6"
                        >
                          {record.text}
                        </Typography>
                      </TableCell>

                      <TableCell sx={{ width: "5%" }}>
                        <Box display="flex" alignItems="center">
                          <Box>
                            <Typography variant="h6" fontWeight={600}>
                              {record.juz}
                            </Typography>
                          </Box>
                        </Box>
                      </TableCell>

                      <TableCell sx={{ width: "40%" }}>
                        <Box display="flex" alignItems="center">
                          <Box>
                            <audio
                              style={{
                                display: record.ayahReciters.find(
                                  (res: any) => res.reciter.id === reciterId
                                )?.attachment
                                  ? "block"
                                  : "none",
                              }}
                              controls
                              src={
                                record.ayahReciters.find(
                                  (res: any) => res.reciter.id === reciterId
                                )?.attachment ?? ""
                              }
                            ></audio>
                          </Box>
                          <Box>
                            <Button
                              component="label"
                              role={undefined}
                              variant="contained"
                              tabIndex={-1}
                              startIcon={<CloudUploadIcon />}
                            >
                              Upload file
                              <VisuallyHiddenInput
                                type="file"
                                onChange={(event) =>
                                  handleFileChange(event, record)
                                }
                              />
                            </Button>
                          </Box>
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              <Pagination
                count={pagination.totalPages}
                page={pagination.currentPage}
                color="primary"
                onChange={handlePageChange}
              />
            </TableContainer>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );
};

export default Page;
