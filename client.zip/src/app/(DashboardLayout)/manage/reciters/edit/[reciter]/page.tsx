"use client"; // Add this line at the top of the parent component
import { useRouter } from "next/navigation";
import AddForm from "../../add/page";
import config from "@/utils/config";
import axios from "axios";
import { useEffect, useState } from "react";

const EditForm = ({params}:any) => {
  const router = useRouter();
  const reciterId = params.reciter
  const [data, setData] = useState<any>([]); // Initialize data as null


  useEffect(() => {

    axios
      .request({
        method: "get",
        maxBodyLength: Infinity,
        url: `${config.apiUrl}reciter/${reciterId}`,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.bearerToken}`,
        },
      })
      .then((response) => {
        console.log("response.data", response.data.data[0]);
        setData(response.data.data[0]);
      })
      .catch((error) => {
        console.log("error");
      });
  }, []);
  


  return (
    <>
    <AddForm data={data}/>
    </>
  );
};

export default EditForm;
