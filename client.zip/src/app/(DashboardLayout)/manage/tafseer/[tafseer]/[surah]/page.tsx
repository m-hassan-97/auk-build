"use client";
import Link from "next/link";
import Swal from "sweetalert2";
import {
  Card,
  CardContent,
  Grid,
  Typography,
  Box,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Chip,
  TableContainer,
  Stack,
  Pagination,
  Button,
  TextField,
} from "@mui/material";
import { useEffect, useState } from "react";
import config from "@/utils/config";
import axios from "axios";
import Image from "next/image";
import aukLogo from "public/images/AuK_logo.webp";
import { Textarea } from "@nextui-org/react";

const Page = ({ params }: any) => {
  console.log("params", params);

  const surahId = params.surah;

  const tafseerId = params.tafseer;

  const [data, setData] = useState<any>([]); // Initialize data as null

  const [pagination, setPagination] = useState({
    total: 0,
    currentPage: 1,
    totalPages: 1,
    limit: 10,
  }); // Initialize with default limit
  const { limit, currentPage } = pagination;

  const [recordData, setrecordData] = useState<any>([]); // Initialize data as null

  var i = 1;

  useEffect(() => {
    fetchRecordData();
    fetchData();
  }, [currentPage, limit]);

  const fetchRecordData = async () => {
    try {
      const response = await axios.request({
        method: "get",
        url: `${config.apiUrl}tafseer/${tafseerId}`,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.bearerToken}`,
        },
      });

      console.log("response.data", response.data.data[0].name);

      setrecordData(response.data?.data[0]?.name);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const fetchData = async () => {
    try {
      const response = await axios.request({
        method: "get",
        url: `${config.apiUrl}surah/${surahId}`,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.bearerToken}`,
        },
        params: {
          page: currentPage, // Pass the current page
          limit, // Pass the limit
          offset: (currentPage - 1) * limit, // Calculate offset
        },
      });

      console.log("response.data.data.total", response.data.data.total);

      setPagination({
        total: response.data.data.total,
        currentPage,
        totalPages: Math.ceil(response.data.data.total / limit),
        limit,
      });

      setData(response.data.data.data[0].ayahs);

      console.log("pagination", pagination);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleDelete = async (id: string) => {
    // Prompt user for confirmation using SweetAlert
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "You will not be able to recover this record!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    });

    if (result.isConfirmed) {
      // User confirmed, send DELETE request to API
      axios
        .request({
          method: "delete",
          maxBodyLength: Infinity,
          url: `${config.apiUrl}reciter/${id}`,
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${config.bearerToken}`,
          },
        })
        .then((response) => {
          Swal.fire("Deleted!", "The record has been deleted.", "success");
          setData(data.filter((record: any) => record.id !== id));
        })
        .catch((error) => {
          Swal.fire("Error!", "Failed to delete the record.", "error");
        });
    }
  };

  const handlePageChange = (event: any, page: any) => {
    console.log("pagination.total", pagination);

    setPagination((prevPagination) => ({
      ...prevPagination,
      currentPage: page,
    }));
  };

  function updateRecord(value: any, id: any) {
    console.log(value, id);

    axios
      .request({
        method: "put",
        maxBodyLength: Infinity,
        url: `${config.apiUrl}ayah/tafseer`,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.bearerToken}`,
        },
        data: JSON.stringify({
          ayahNumber: id,
          tafseerId: tafseerId,
          tafseer: value,
        }),
      })
      .then((response) => {
        // Swal.fire(
        //   "Success",
        //   "Record has been updated successfully!",
        //   "success"
        // );

        console.log("response");
        console.log(response.data);
      });
  }

  return (
    <Grid container spacing={0}>
      <Grid item xs={12} lg={12}>
        <Card sx={{ padding: 0 }} elevation={9} variant={undefined}>
          <CardContent sx={{ p: "30px" }}>
            <Stack
              direction="row"
              spacing={2}
              justifyContent="space-between"
              alignItems={"center"}
              mb={3}
            >
              <Box>
                <Typography variant="h3">Quran</Typography>

                <Typography variant="h4">tafseer : {recordData}</Typography>
                <Typography variant="h4">Surah Number : {surahId}</Typography>
              </Box>
            </Stack>

            <TableContainer
              sx={{
                width: {
                  xs: "274px",
                  sm: "100%",
                },
              }}
            >
              <Table
                aria-label="simple table"
                sx={{
                  whiteSpace: "nowrap",
                  mt: 2,
                }}
              >
                <TableHead>
                  <TableRow>
                    <TableCell>
                      <Typography color="textSecondary" variant="h6">
                        Juz
                      </Typography>
                    </TableCell>

                    <TableCell>
                      <Typography color="textSecondary" variant="h6">
                        Ayah
                      </Typography>
                    </TableCell>

                    <TableCell>
                      <Typography color="textSecondary" variant="h6">
                        Juz
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography color="textSecondary" variant="h6">
                        tafseer
                      </Typography>
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {data?.map((record: any) => (
                    <TableRow key={record.number}>
                      <TableCell sx={{ width: "5%" }}>
                        <Typography fontSize="15px" fontWeight={500}>
                          {i++}
                        </Typography>
                      </TableCell>

                      <TableCell sx={{ width: "30%" }}>
                        <Typography
                          style={{ textWrap: "wrap" }}
                          color="textSecondary"
                          variant="h6"
                        >
                          {record.text}
                        </Typography>
                      </TableCell>

                      <TableCell sx={{ width: "5%" }}>
                        <Box display="flex" alignItems="center">
                          <Box>
                            <Typography variant="h6" fontWeight={600}>
                              {record.juz}
                            </Typography>
                          </Box>
                        </Box>
                      </TableCell>

                      <TableCell>
                        <Textarea
                          style={{ width: "100%", height: "150px" }}
                          id="tafseer"
                          label="tafseer"
                          placeholder="Enter tafseer"
                          defaultValue={
                            record?.ayahTafseers.find(
                              (res: any) => res.tafseer.id === tafseerId
                            )?.ayahTafseer ?? ""
                          }
                          onChange={(e) =>
                            updateRecord(e.target.value, record.number)
                          }
                        />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              <Pagination
                count={pagination.totalPages}
                page={pagination.currentPage}
                color="primary"
                onChange={handlePageChange}
              />
            </TableContainer>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );
};

export default Page;
