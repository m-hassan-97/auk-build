"use client"; // Add this line at the top of the parent component

import BaseCard from "@/app/(DashboardLayout)/components/shared/BaseCard";
import { createTheme, ThemeProvider, styled } from "@mui/material/styles";
import { CSSProperties, useEffect, useState } from "react";
import {
  Paper,
  Grid,
  Stack,
  TextField,
  Button,
  Box,
  FormLabel,
} from "@mui/material";
import axios from "axios";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import Swal from "sweetalert2";

import { useRouter } from "next/navigation";

import AWS from "aws-sdk";
import config from "@/utils/config";
import Image from "next/image";
import ClipLoader from "react-spinners/ClipLoader";
import { FadeLoader } from "react-spinners";

const override: CSSProperties = {
  display: "block",
  margin: "0 auto",
  borderColor: "red",
};

const VisuallyHiddenInput = styled("input")({
  clip: "rect(0 0 0 0)",
  clipPath: "inset(50%)",
  height: 1,
  overflow: "hidden",
  position: "absolute",
  bottom: 0,
  left: 0,
  whiteSpace: "nowrap",
  width: 1,
});

const AddForm = (data: any) => {
  const router = useRouter();
  const [selectedFile, setSelectedFile] = useState<any>(null);
  const [fileName, setFileName] = useState<any>("");
  const [name, setName] = useState<any>("");
  const [id, setId] = useState<any>("");

  const [writer, setWriter] = useState<any>("");
  const [image, setImage] = useState<any>("");
  const [error, setError] = useState(null);

  const [uploadingStatus, setUploadingStatus] = useState<boolean>(false);

  useEffect(() => {
    console.log("data", data);

    if (data?.data) {
      let d = data.data;
      console.log("data", data.data);
      setId(d.id);
      setName(d.name);
      setWriter(d.writer);
      setImage(d.image);
      setFileName(config.getNamebyFileUrl(d.image));
    }
  }, [data]);

  // const handleFileChange = async (event: any) => {

  //   console.log("event.target.files",event.target.files);

  //   if (event.target.files[0]) {
  //     console.log("event.target.files[0]", event.target.files[0]);
  //     const selectedFileTemp = event.target.files[0];
  //     await setSelectedFile(event.target.files[0]);

  //     console.log("selectedFile", selectedFile);
  //     console.log("selectedFileTemp", selectedFileTemp);

  //     if (selectedFileTemp) {
  //       setFileName(selectedFileTemp.name);
  //     }

  //     const s3 = new AWS.S3({
  //       accessKeyId: "AKIAU6GDVB4AKL2MFI5J",
  //       secretAccessKey: "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",
  //       region: "us-east-1",
  //     });
  //     const params = {
  //       Bucket: "ahsan-ul-kalam",
  //       Key: `images/tafseer/${selectedFileTemp.name}`,
  //       Body: selectedFileTemp,
  //     };
  //     setUploadingStatus(true);
  //     console.log("uploadingStatus", uploadingStatus);
  //     await s3.upload(params, (err: any, data: any) => {
  //       setUploadingStatus(false);
  //       console.log("uploadingStatus", uploadingStatus);

  //       if (err) {
  //         console.error("Error uploading file:", err);
  //         return;
  //       }
  //       console.log("File uploaded successfully:", data);
  //       setImage(data.Location);
  //     });
  //   }
  // };

  const saveData = async () => {
    console.log("name", name);
    if (name.length < 3) {
      Swal.fire("Error", "Invalid Name value", "error");
      return;
    }

    if (writer.length < 3) {
      Swal.fire("Error", "Invalid Writer value", "error");
      return;
    }

    // if (!selectedFile) {
    //   Swal.fire("Error", "Please select your image first", "error");
    //   return;
    // }

    // if (!selectedFile) {
    //   throw new Error("Please select a file");
    // }

    axios
      .request({
        method: `${id ? "put" : "post"}`,
        maxBodyLength: Infinity,
        url: `${config.apiUrl}tafseer/${id ? id : "create"}`,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.bearerToken}`,
        },
        data: JSON.stringify({
          name: name,
          writer: writer,
        }),
      })
      .then((response) => {
        console.log("response");
        console.log(response.data);

        if (id) {
          Swal.fire(
            "Success",
            "tafseer has been updated successfully!",
            "success"
          );
        } else {
          Swal.fire(
            "Success",
            "tafseer has been created successfully!",
            "success"
          );
        }
        router.push("/manage/tafseer"); // Replace "/different-route" with your desired route
        // Reset form after successful submission
        setSelectedFile(null);
        setName("");
        setWriter("");
        setImage(""); // Assuming the response contains the image URL
        setFileName("");
      });
  };

  return (
    <Grid container spacing={3}>
      <Grid item xs={12} lg={12}>
        <BaseCard title={id ? "Add tafseer" : "Edit tafseer"}>
          {uploadingStatus ? (
            <Grid container>
              <Grid item xs={5} lg={5}>
                {" "}
              </Grid>
              <Grid item container xs={2} lg={2}>
                <FadeLoader color="#36d7b7" /> <h3> Uploading</h3>{" "}
              </Grid>
              <Grid item xs={5} lg={5}>
                {" "}
              </Grid>
            </Grid>
          ) : (
            <>
              <Stack spacing={3}>
                <TextField
                  id="name"
                  label="Name"
                  variant="outlined"
                  placeholder="Enter Name"
                  value={name} // Add value prop
                  onChange={(e) => setName(e.target.value)} // Add onChange handler
                />

                <TextField
                  id="writer"
                  label="Writer"
                  variant="outlined"
                  placeholder="Enter Writer"
                  value={writer} // Add value prop
                  onChange={(e) => setWriter(e.target.value)} // Add onChange handler
                />

                {/* 
                {image ? (
                  <>
                    <FormLabel>Preview</FormLabel>
                    <Image src={image} alt="img" width={80} height={80} />{" "}
                  </>
                ) : (
                  ""
                )}

                <Button
                  component="label"
                  role={undefined}
                  variant="contained"
                  tabIndex={-1}
                  startIcon={<CloudUploadIcon />}
                >
                  {fileName ? `Uploaded file : ${fileName}` : "Upload file"}
                  <VisuallyHiddenInput
                    type="file"
                    onChange={handleFileChange}
                  />
                </Button> */}

                {error && <Box color="error">{error}</Box>}
              </Stack>
              <br />

              <Grid container>
                <Grid item sm={12}>
                  <Box display="flex" justifyContent="flex-end">
                    <Button
                      variant="contained"
                      onClick={saveData}
                      color="success"
                    >
                      Save
                    </Button>
                  </Box>
                </Grid>
              </Grid>
            </>
          )}
        </BaseCard>
      </Grid>
    </Grid>
  );
};

export default AddForm;
