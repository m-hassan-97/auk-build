import React from "react";
import {
  Typography,
  Box,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Chip,
  TableContainer,
  Grid,
  Stack,
  Pagination
} from "@mui/material";
import BaseCard from "../shared/DashboardCard";

const products = [
  {
    id: "1",
    name: "Kanzul Iman",
    writer: "Ahmed Raza Khan Barelvi",
    status: "Inactive",
    pbg: "primary.main",
  },
  {
    id: "2",
    name: "Bayan Ul Quran",
    writer: "Ashraf Ali Thanwi",
    status: "Active",
    pbg: "success.main",
  },
  {
    id: "3",
    name: "Maarif al-Quran ",
    writer: "Idris Kandhlawi",
    status: "Active",
    pbg: "success.main",
  },
  {
    id: "4",
    name: "Anwaral-Qur'an",
    writer: "Abal-Kalam Ma'sum",
    status: "Active",
    pbg: "success.main",
  },
];

const ProductPerfomance = () => {
  return (
    <BaseCard title="Manage Tafseer" addButton="Add New">
      <TableContainer
        sx={{
          width: {
            xs: "274px",
            sm: "100%",
          },
        }}
      >
        <Table
          aria-label="simple table"
          sx={{
            whiteSpace: "nowrap",
            mt: 2,
          }}
        >
          <TableHead>
            <TableRow>
              <TableCell>
                <Typography color="textSecondary" variant="h6">
                  Id
                </Typography>
              </TableCell>
              <TableCell>
                <Typography color="textSecondary" variant="h6">
                  Name
                </Typography>
              </TableCell>
              <TableCell>
                <Typography color="textSecondary" variant="h6">
                  Writer
                </Typography>
              </TableCell>
              <TableCell>
                <Typography color="textSecondary" variant="h6">
                  Status
                </Typography>
              </TableCell>
              <TableCell align="right">
                <Typography color="textSecondary" variant="h6">
                  Action
                </Typography>
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {products.map((product) => (
              <TableRow key={product.name}>
                <TableCell>
                  <Typography fontSize="15px" fontWeight={500}>
                    {product.id}
                  </Typography>
                </TableCell>
                <TableCell>
                  <Box display="flex" alignItems="center">
                    <Box>
                      <Typography variant="h6" fontWeight={600}>
                        {product.name}
                      </Typography>
                      {/* <Typography color="textSecondary" fontSize="13px">
                        {product.post}
                      </Typography> */}
                    </Box>
                  </Box>
                </TableCell>
                <TableCell>
                  <Typography color="textSecondary" variant="h6">
                    {product.writer}
                  </Typography>
                </TableCell>
                <TableCell>
                  <Chip
                    sx={{
                      pl: "4px",
                      pr: "4px",
                      backgroundColor: product.pbg,
                      color: "#fff",
                    }}
                    size="small"
                    label={product.status}
                  ></Chip>
                </TableCell>
                <TableCell align="right">
                 
                <Chip
                    sx={{
                      pl: "4px",
                      pr: "4px",
                      backgroundColor: 'error.main',
                      color: "#fff",
                    }}
                    size="small"
                    label='Delete'
                  ></Chip>

                <Chip
                    sx={{
                      pl: "4px",
                      pr: "4px",
                      backgroundColor: 'secondary.main',
                      color: "#fff",
                    }}
                    size="small"
                    label='Edit'
                  ></Chip>
                  
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        <Pagination count={10} color="primary" />

      </TableContainer>
    </BaseCard>


  );
};

export default ProductPerfomance;
