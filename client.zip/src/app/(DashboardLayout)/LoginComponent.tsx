import React, { useState } from "react";
import { Button, TextField, Typography, Box } from "@mui/material";

import { useRouter } from "next/navigation";

const LoginComponent = () => {
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  
  const handleLogin = () => {
    // Perform your login logic here, e.g., call an API
    if (email === "admin@auk.com" && password === "admin.123") {
      // Successful login
      setError("");
      // Save login state to localStorage
      localStorage.setItem("isLoggedIn", "true");
      // Redirect to dashboard page
      window.location.reload();
     
    } else {
      // Failed login
      setError("Invalid email or password");
    }
  };

  return (
    <Box sx={{ maxWidth: 400, mx: "auto", mt: 8, p: 2 }}>
      <Typography variant="h4" gutterBottom>
        Login
      </Typography>
      {error && (
        <Typography variant="body2" color="error" gutterBottom>
          {error}
        </Typography>
      )}
      <TextField
        label="Email"
        variant="outlined"
        fullWidth
        margin="normal"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <TextField
        label="Password"
        variant="outlined"
        fullWidth
        margin="normal"
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <Button
        variant="contained"
        color="primary"
        fullWidth
        onClick={handleLogin}
      >
        Login
      </Button>
    </Box>
  );
};

export default LoginComponent;
