import Link from "next/link";
import { styled } from "@mui/material";
import Image from "next/image";

const LinkStyled = styled(Link)(() => ({
  height: "40px",
  width: "180px",
  overflow: "hidden",
  display: "block",
}));

import aukLogo from "public/images/AuK_logo.webp";

const Logo = () => {
  return (
      <Image src={aukLogo} alt="logo" height={80} width={80} priority />
    
  );
};

export default Logo;
