const config = {
  //apiUrl: "http://localhost:8000/",
  apiUrl: "http://54.160.250.211:8000/",
  bearerToken:
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6ImU4MDFhNDFjLTFhZjQtNDUxZC05YmJlLWM1NDRkMjBkMTNmNSIsImltYWdlIjpudWxsLCJmaXJzdE5hbWUiOiJNdWhhbW1hZCIsImxhc3ROYW1lIjoiSGFzc2FuIiwiZW1haWwiOiJoYXNzYW4xQGdtYWlsLmNvbSIsInVzZXJOYW1lIjoiaGFzc2FuMUBnbWFpbC5jb20iLCJpYXQiOjE3MTIxOTY2NjgsImV4cCI6MTcxMjIwMDI2OH0.FCxnh9HEi_HFiu1MWV53mfL2TSgIkXLEEn3IXLC33iQ",
  getNamebyFileUrl(url: string) {
    if (url) {
      const parts = url.split("/");
      const filename = parts[parts.length - 1]; // Get the last part of the URL
      return filename; // Output: "sudais.jpeg"
    } else {
      return "";
    }
  },
};

export default config;
